Owen McCullough Photography Website
-----------------------------------
Files:
- index.html : main page (customized with your details)
- styles.css : styles
- script.js  : smooth scrolling

How to use:
1. Download the zip file and unzip it.
2. You can edit index.html anytime to update text, email, or socials.
3. Deploy for free:
   - GitHub Pages: push files to a GitHub repo and enable Pages in settings.
   - Netlify or Vercel: drag and drop the folder for instant free hosting.
